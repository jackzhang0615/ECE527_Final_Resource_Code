// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.1 (64-bit)
// Tool Version Limit: 2025.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XGEMM_ACCEL_H
#define XGEMM_ACCEL_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xgemm_accel_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XGemm_accel_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XGemm_accel;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XGemm_accel_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XGemm_accel_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XGemm_accel_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XGemm_accel_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XGemm_accel_Initialize(XGemm_accel *InstancePtr, UINTPTR BaseAddress);
XGemm_accel_Config* XGemm_accel_LookupConfig(UINTPTR BaseAddress);
#else
int XGemm_accel_Initialize(XGemm_accel *InstancePtr, u16 DeviceId);
XGemm_accel_Config* XGemm_accel_LookupConfig(u16 DeviceId);
#endif
int XGemm_accel_CfgInitialize(XGemm_accel *InstancePtr, XGemm_accel_Config *ConfigPtr);
#else
int XGemm_accel_Initialize(XGemm_accel *InstancePtr, const char* InstanceName);
int XGemm_accel_Release(XGemm_accel *InstancePtr);
#endif

void XGemm_accel_Start(XGemm_accel *InstancePtr);
u32 XGemm_accel_IsDone(XGemm_accel *InstancePtr);
u32 XGemm_accel_IsIdle(XGemm_accel *InstancePtr);
u32 XGemm_accel_IsReady(XGemm_accel *InstancePtr);
void XGemm_accel_EnableAutoRestart(XGemm_accel *InstancePtr);
void XGemm_accel_DisableAutoRestart(XGemm_accel *InstancePtr);

void XGemm_accel_Set_A(XGemm_accel *InstancePtr, u64 Data);
u64 XGemm_accel_Get_A(XGemm_accel *InstancePtr);
void XGemm_accel_Set_B(XGemm_accel *InstancePtr, u64 Data);
u64 XGemm_accel_Get_B(XGemm_accel *InstancePtr);
void XGemm_accel_Set_C(XGemm_accel *InstancePtr, u64 Data);
u64 XGemm_accel_Get_C(XGemm_accel *InstancePtr);
void XGemm_accel_Set_M(XGemm_accel *InstancePtr, u32 Data);
u32 XGemm_accel_Get_M(XGemm_accel *InstancePtr);
void XGemm_accel_Set_N(XGemm_accel *InstancePtr, u32 Data);
u32 XGemm_accel_Get_N(XGemm_accel *InstancePtr);
void XGemm_accel_Set_K(XGemm_accel *InstancePtr, u32 Data);
u32 XGemm_accel_Get_K(XGemm_accel *InstancePtr);
void XGemm_accel_Set_row_start(XGemm_accel *InstancePtr, u32 Data);
u32 XGemm_accel_Get_row_start(XGemm_accel *InstancePtr);
void XGemm_accel_Set_row_count(XGemm_accel *InstancePtr, u32 Data);
u32 XGemm_accel_Get_row_count(XGemm_accel *InstancePtr);
void XGemm_accel_Set_work(XGemm_accel *InstancePtr, u64 Data);
u64 XGemm_accel_Get_work(XGemm_accel *InstancePtr);

void XGemm_accel_InterruptGlobalEnable(XGemm_accel *InstancePtr);
void XGemm_accel_InterruptGlobalDisable(XGemm_accel *InstancePtr);
void XGemm_accel_InterruptEnable(XGemm_accel *InstancePtr, u32 Mask);
void XGemm_accel_InterruptDisable(XGemm_accel *InstancePtr, u32 Mask);
void XGemm_accel_InterruptClear(XGemm_accel *InstancePtr, u32 Mask);
u32 XGemm_accel_InterruptGetEnabled(XGemm_accel *InstancePtr);
u32 XGemm_accel_InterruptGetStatus(XGemm_accel *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
